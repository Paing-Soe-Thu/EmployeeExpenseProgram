package BTEC_Accessment;

import java.util.ArrayList;

public interface IExpense {
        public abstract double calculateSavings(ArrayList<Expense> expenses);

}
